"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { ImageUploader } from "@/components/image-uploader"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Loader2, Download, ImageIcon, Sparkles, AlertCircle } from "lucide-react"
import { generateImage } from "@/app/actions"
import { cn } from "@/lib/utils"

type FormData = {
  prompt: string
}

export function ImageGenerator() {
  const [referenceImage, setReferenceImage] = useState<string | null>(null)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [imageDescription, setImageDescription] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("text-to-image")

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>()

  const onSubmit = async (data: FormData) => {
    try {
      setIsGenerating(true)
      setError(null)
      setImageDescription(null)
      setGeneratedImage(null)

      const result = await generateImage({
        prompt: data.prompt,
        referenceImage: activeTab === "image-to-image" ? referenceImage : null,
      })

      if (result.error) {
        setError(result.error)
      }

      if (result.description) {
        setImageDescription(result.description)
      }

      if (result.imageUrl) {
        setGeneratedImage(result.imageUrl)
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
      console.error(err)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleImageUpload = (imageDataUrl: string) => {
    setReferenceImage(imageDataUrl)
  }

  const downloadImage = () => {
    if (!generatedImage) return

    const prefix = "Text2Image"
    const timestamp = Date.now()
    const imageNumber = Math.floor(Math.random() * 1000) + 1

    const link = document.createElement("a")
    link.href = generatedImage
    link.download = `${prefix}_Image${imageNumber}.png`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-8">
      <Card className="p-4 sm:p-6">
        <form onSubmit={handleSubmit(onSubmit)}>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-4 sm:mb-6">
              <TabsTrigger value="text-to-image">
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Image
              </TabsTrigger>
              <TabsTrigger value="image-to-image">
                <ImageIcon className="w-4 h-4 mr-2" />
                Modify Image
              </TabsTrigger>
            </TabsList>

            <TabsContent value="text-to-image" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="prompt">Describe the image you want to generate</Label>
                <Textarea
                  id="prompt"
                  placeholder="A serene landscape with mountains, a lake, and a sunset..."
                  className="min-h-[120px]"
                  {...register("prompt", { required: "Please enter a prompt" })}
                />
                {errors.prompt && <p className="text-sm text-red-500">{errors.prompt.message}</p>}
              </div>
            </TabsContent>

            <TabsContent value="image-to-image" className="space-y-4">
              <div className="space-y-2">
                <Label>Upload an image to modify</Label>
                <ImageUploader
                  onImageUpload={handleImageUpload}
                  onImageDelete={() => setReferenceImage(null)}
                  currentImage={referenceImage}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="prompt">Describe the changes you want to make</Label>
                <Textarea
                  id="prompt"
                  placeholder="Using this reference, create an image with a watercolor style..."
                  className="min-h-[120px]"
                  {...register("prompt", { required: "Please enter a prompt" })}
                />
                {errors.prompt && <p className="text-sm text-red-500">{errors.prompt.message}</p>}
              </div>
            </TabsContent>
          </Tabs>

          <Button
            type="submit"
            className="w-full mt-6"
            disabled={isGenerating || (activeTab === "image-to-image" && !referenceImage)}
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Image
              </>
            )}
          </Button>

          {activeTab === "image-to-image" && !referenceImage && (
            <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 text-sm rounded-md flex items-start">
              <AlertCircle className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
              <span>Please upload an image first</span>
            </div>
          )}

          {error && (
            <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm rounded-md">
              {error}
            </div>
          )}
        </form>
      </Card>

      <div className="space-y-6">
        <Card
          className={cn(
            "p-6 flex flex-col items-center justify-center min-h-[400px]",
            !generatedImage && "bg-slate-50 dark:bg-slate-800/50"
          )}
        >
          {isGenerating ? (
            <div className="flex flex-col items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
              <p className="text-slate-500 dark:text-slate-400">Generating image...</p>
            </div>
          ) : generatedImage ? (
            <div className="w-full">
              <Dialog>
                <DialogTrigger asChild>
                  <div className="relative aspect-square w-full overflow-hidden rounded-md border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <img
                      src={generatedImage || "/placeholder.svg"}
                      alt="Generated"
                      className="object-contain w-full h-full"
                    />
                  </div>
                </DialogTrigger>
                <DialogContent className="max-w-4xl p-0 overflow-hidden bg-transparent border-0">
                  <DialogTitle className="sr-only">Generated Image Preview</DialogTitle>
                  <img
                    src={generatedImage || "/placeholder.svg"}
                    alt="Generated"
                    className="object-contain w-full h-full"
                  />
                </DialogContent>
              </Dialog>
              {imageDescription && (
                <p className="mt-4 text-sm text-muted-foreground">{imageDescription}</p>
              )}
              <Button
                onClick={downloadImage}
                className="mt-4 w-full"
                disabled={!generatedImage}
              >
                <Download className="mr-2 h-4 w-4" />
                Download Image
              </Button>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-muted-foreground">
              <ImageIcon className="h-8 w-8 mb-4" />
              <p>Generated image will appear here</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}

