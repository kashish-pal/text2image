"use client"

import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet"
import { Menu } from "lucide-react"
import { motion } from "framer-motion"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center space-x-2">
          <Link href="/" className="flex items-center space-x-2">
            <span className="font-bold inline-block text-primary">Text2Image</span>
            <Badge variant="outline" className="font-normal text-primary border-primary">BETA</Badge>
          </Link>
          <Badge variant="outline" className="hidden sm:inline-flex text-primary border-primary">100% Free</Badge>
        </div>
        <div className="flex items-center">
          <nav className="hidden md:flex items-center space-x-6 lg:space-x-8">
            <Link href="/" className="text-sm font-medium transition-colors hover:text-primary">
              Home
            </Link>
            <motion.div
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 500, damping: 7 }}
            >
              <Link href="/tool" className="text-sm font-medium px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors">
                Tool
              </Link>
            </motion.div>
            <Link href="/contact" className="text-sm font-medium transition-colors hover:text-primary">
              Contact Us
            </Link>
          </nav>
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="fixed top-0 border-r bg-white w-[280px] max-h-[280px] rounded-br-lg shadow-lg">
              <div className="flex flex-col h-full">
                <div className="p-2 border-b">
                  <Link href="/" className="flex items-center space-x-2">
                    <span className="font-bold inline-block text-primary">Text2Image</span>
                    <Badge variant="outline" className="font-normal text-primary border-primary">BETA</Badge>
                  </Link>
                </div>
                <nav className="flex flex-col space-y-1 py-2 px-2">
                  <Link href="/" className="text-sm font-medium px-2 py-1.5 rounded-md transition-colors hover:bg-primary/10 hover:text-primary">
                    Home
                  </Link>
                  <motion.div
                    whileHover={{ scale: 1.02, x: 4 }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  >
                    <Link href="/tool" className="text-sm font-medium px-2 py-1.5 rounded-md transition-colors hover:bg-primary/10 hover:text-primary">
                      Tool
                    </Link>
                  </motion.div>
                  <Link href="/contact" className="text-sm font-medium px-2 py-1.5 rounded-md transition-colors hover:bg-primary/10 hover:text-primary">
                    Contact
                  </Link>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}