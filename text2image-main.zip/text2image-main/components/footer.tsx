"use client"

import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Github, Twitter, Mail } from "lucide-react"

export function Footer() {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container py-10 grid gap-8 grid-cols-1 md:grid-cols-2">
        <div className="space-y-3">
          <h4 className="font-semibold text-primary">Text2Image</h4>
          <p className="text-sm text-muted-foreground">
            Transform your ideas into stunning images with AI - completely free.
          </p>
        </div>
        <div className="space-y-3 md:ml-auto">
          <h4 className="font-semibold text-primary">Quick Links</h4>
          <nav className="flex flex-row gap-4">
            <Link href="/" className="text-sm text-muted-foreground hover:text-foreground">
              Home
            </Link>
            <Link href="/tool" className="text-sm text-muted-foreground hover:text-foreground">
              Tool
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
              Contact Us
            </Link>
            <Link href="/terms-policy?tab=privacy" className="text-sm text-muted-foreground hover:text-foreground">
              Privacy Policy
            </Link>
            <Link href="/terms-policy?tab=terms" className="text-sm text-muted-foreground hover:text-foreground">
              Terms of Use
            </Link>
          </nav>
        </div>
      </div>
      <div className="container py-6 flex flex-col md:flex-row justify-center items-center border-t">
        <p className="text-sm text-muted-foreground text-center">
          © 2025 Text2Image. All rights reserved. Designed by <Link href="https://www.ai101services.com" className="text-muted-foreground hover:text-foreground hover:underline">AI101</Link>. Powered by Gemini 2.0
        </p>

      </div>
    </footer>
  )
}