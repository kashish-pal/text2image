"use client"

import { useEffect } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import Script from 'next/script'

interface RecaptchaFormProps {
  formUrl: string
  title: string
}

declare global {
  interface Window {
    grecaptcha: any
    onRecaptchaLoad: () => void
    onFormSubmit: () => void
  }
}

export function RecaptchaForm({ formUrl, title }: RecaptchaFormProps) {
  useEffect(() => {
    window.onRecaptchaLoad = () => {
      window.grecaptcha.render('submit-button', {
        sitekey: process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY,
        callback: () => {
          const iframe = document.querySelector('iframe[src^="https://forms.gle"]') as HTMLIFrameElement
          if (iframe) {
            const submitButton = iframe.contentDocument?.querySelector('button[type="submit"]')
            submitButton?.click()
          }
        }
      })
    }
  }, [])

  return (
    <>
      <Script
        src="https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad&render=explicit"
        async
        defer
      />
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{title}</DialogTitle>
        </DialogHeader>
        <div className="relative">
          <iframe
            src={formUrl}
            className="w-full h-[75vh] border-0 rounded-lg"
            title={title}
          />
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
            <div id="submit-button"></div>
          </div>
        </div>
      </DialogContent>
    </>
  )
}