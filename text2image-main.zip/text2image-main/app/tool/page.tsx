"use client"

import { ImageGenerator } from "@/components/image-generator"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

export default function ToolPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 container py-8">
        <div className="max-w-5xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <h1 className="text-4xl md:text-6xl font-bold tracking-tighter">Text2Image</h1>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="font-normal text-primary border-primary">BETA</Badge>
                <Badge variant="outline" className="text-primary border-primary">100% Free</Badge>
              </div>
            </div>
            <p className="text-xl text-muted-foreground max-w-[600px] mx-auto">
              Transform your images using simple text descriptions.
            </p>
            <p className="text-sm text-muted-foreground max-w-[600px] mx-auto">
              This is a Beta version. If you encounter any issues with generating images, please report them via our <Link href="/contact" className="text-primary hover:underline">Contact Us</Link> page.
            </p>
          </div>
          <ImageGenerator />
        </div>
      </main>
      <Footer />
    </div>
  )
}