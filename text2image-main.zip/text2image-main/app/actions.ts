"use server"

import { GoogleGenerativeAI } from "@google/generative-ai"

// Initialize the Google Generative AI client with the environment variable
const API_KEY = process.env.GEMINI_API_KEY
if (!API_KEY || API_KEY.trim() === "") {
  throw new Error("Gemini API key is not configured. Please add your API key to the environment variables.")
}
const genAI = new GoogleGenerativeAI(API_KEY)

interface GenerateImageParams {
  prompt: string
  referenceImage?: string | null
}

export async function generateImage({ prompt, referenceImage }: GenerateImageParams) {
  try {
    // API key validation is done at initialization

    // Get the Gemini 2.0 Flash Experimental model
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" })

    let result

    if (referenceImage) {
      // If a reference image is provided, include it in the prompt
      // Extract the base64 data from the data URL
      const base64Data = referenceImage.split(",")[1]

      // Create a file part from the base64 data
      // Extract MIME type from the data URL
      const mimeType = referenceImage.split(";")[0].split(":")[1]

      const imagePart = {
        inlineData: {
          data: base64Data,
          mimeType: mimeType,
        },
      }

      // Generate content with reference image
      result = await model.generateContent({
        contents: [
          {
            role: "user",
            parts: [{ text: `Based on this reference image, generate a new image that: ${prompt}` }, imagePart],
          },
        ],
        generationConfig: {
          // Request both text and image in the response
          responseModalities: ["Text", "Image"],
        },
      })
    } else {
      // Text-to-image generation
      result = await model.generateContent({
        contents: [
          {
            role: "user",
            parts: [{ text: `Generate an image of: ${prompt}` }],
          },
        ],
        generationConfig: {
          // Request both text and image in the response
          responseModalities: ["Text", "Image"],
        },
      })
    }

    const response = await result.response

    // Extract text and image from the response
    const parts = response.candidates?.[0]?.content?.parts || []

    // Find the image part
    const imagePart = parts.find((part) => part.inlineData?.mimeType?.startsWith("image/"))

    // Find text parts
    const textParts = parts.filter((part) => part.text).map((part) => part.text)
    const textDescription = textParts.join("\n")

    if (!imagePart || !imagePart.inlineData) {
      return {
        error: "No image was generated. Try a different prompt.",
        description: textDescription || null,
      }
    }

    // Create a data URL from the image data
    const imageUrl = `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`

    return {
      imageUrl,
      description: textDescription || null,
    }
  } catch (error) {
    console.error("Error generating image:", {
      error,
      prompt,
      hasReferenceImage: !!referenceImage,
      timestamp: new Date().toISOString(),
    })

    // Handle specific error types
    if (error instanceof Error) {
      if (error.message.includes("API key")) {
        return { error: "Service configuration error. Please contact support." }
      }
      if (error.message.includes("quota") || error.message.includes("rate limit")) {
        return { error: "Service is temporarily busy. Please try again in a few minutes." }
      }
      if (error.message.includes("content policy")) {
        return { error: "The request could not be processed due to content restrictions. Please try a different prompt." }
      }
    }

    return {
      error: "An error occurred while processing your request. Please try again with a different prompt."
    }
  }
}

