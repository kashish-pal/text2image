import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Text2Image - AI-Powered Image Editor",
  description: "Transform your images with AI using Text2Image. Upload a photo, describe your desired changes, and let our advanced AI technology bring your vision to life.",
  generator: "Text2Image",
  metadataBase: new URL("https://text2image.net"),
  authors: [{ name: "Text2Image Team" }],
  keywords: ["AI image editor", "text to image", "image transformation", "AI photo editing", "Gemini AI"],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://text2image.net",
    title: "Text2Image - Transform Your Images with AI",
    description: "Transform your images with AI using Text2Image. Upload a photo, describe your desired changes, and let our advanced AI technology bring your vision to life.",
    siteName: "Text2Image",
    images: [{
      url: "https://text2image.net/og-image.jpg",
      width: 1200,
      height: 630,
      alt: "Text2Image AI Editor Preview"
    }]
  },
  twitter: {
    card: "summary_large_image",
    title: "Text2Image - AI-Powered Image Editor",
    description: "Transform your images with AI using Text2Image. Upload a photo, describe your desired changes, and let our advanced AI technology bring your vision to life.",
    images: ["https://text2image.net/twitter-image.jpg"],
    creator: "@text2image"
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: "google-site-verification-code",
    other: {
      me: ["https://text2image.net"]
    }
  },
  alternates: {
    canonical: "https://text2image.net"
  }
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}