"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function TermsPolicy() {
  const [showBackToTop, setShowBackToTop] = useState(false)

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleScroll = () => {
    if (window.scrollY > 300) {
      setShowBackToTop(true)
    } else {
      setShowBackToTop(false)
    }
  }

  if (typeof window !== "undefined") {
    window.addEventListener("scroll", handleScroll)
  }

  const TableOfContents = ({ sections, prefix }) => (
    <div className="mb-8 p-4 bg-muted/30 rounded-lg border border-border/50">
      <h2 className="text-xl font-semibold mb-4">Table of Contents</h2>
      <ul className="space-y-2">
        {sections.map((section, index) => (
          <li key={index}>
            <a
              href={`#${prefix}-${index + 1}`}
              className="text-primary hover:underline"
              onClick={(e) => {
                e.preventDefault()
                const element = document.getElementById(`${prefix}-${index + 1}`)
                if (element) {
                  element.scrollIntoView({ behavior: "smooth" })
                }
              }}
            >
              {section}
            </a>
          </li>
        ))}
      </ul>
    </div>
  )

  const termsSection = [
    "Introduction",
    "Description of Service",
    "User Obligations",
    "Intellectual Property",
    "Third-Party Services",
    "Limitation of Liability",
    "Disclaimer of Warranties",
    "Changes to Terms",
    "Termination",
    "Governing Law",
  ]

  const privacySection = [
    "Introduction",
    "Information We Collect",
    "How We Use Your Information",
    "Third-Party Services",
    "Data Retention",
    "Data Security",
    "Your Rights",
    "Children's Privacy",
    "Changes to This Privacy Policy",
    "Contact Us"
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-8">
          <div className="container max-w-4xl">
            <Tabs defaultValue="terms" className="space-y-8">
              <div className="flex flex-col items-center space-y-4">
                <h1 className="text-4xl md:text-6xl font-bold tracking-tighter">
                  Legal Information
                </h1>
                <TabsList className="grid w-full max-w-md grid-cols-2">
                  <TabsTrigger value="terms">Terms of Use</TabsTrigger>
                  <TabsTrigger value="privacy">Privacy Policy</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="terms" className="space-y-8">
                <div className="text-sm text-muted-foreground text-center">
                  Last Updated: March 2025
                </div>
                <TableOfContents sections={termsSection} prefix="terms" />
                
                <div className="space-y-12">
                  <section id="terms-1" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">1. Introduction</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      Welcome to Text2Image ("we," "our," or "us"). By accessing or using our website and services, you agree to be bound by these Terms of Use. If you do not agree with any part of these terms, please do not use our service.
                    </p>
                  </section>

                  <section id="terms-2" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">2. Description of Service</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      Text2Image is a web-based tool that allows users to upload images and provide text prompts to transform these images using artificial intelligence. Our service utilizes Google's Gemini 2 AI technology to process and generate these transformations.
                    </p>
                  </section>

                  <section id="terms-3" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">3. User Obligations</h2>
                    <p className="text-muted-foreground leading-relaxed mb-4">
                      When using Text2Image, you agree to:
                    </p>
                    <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                      <li>Provide accurate information when using our service</li>
                      <li>Use the service for lawful purposes only</li>
                      <li>Not upload or generate content that is illegal, harmful, threatening, abusive, harassing, defamatory, vulgar, obscene, or otherwise objectionable</li>
                      <li>Not attempt to interfere with the proper working of the service</li>
                      <li>Not circumvent, disable, or interfere with security-related features of the service</li>
                    </ul>
                  </section>

                  <section id="terms-4" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">4. Intellectual Property</h2>
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-xl font-semibold mb-2">4.1 Our Rights</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          The Text2Image website, including its design, text, graphics, logos, icons, and software, is the property of Text2Image and is protected by copyright and other intellectual property laws. You may not reproduce, distribute, modify, or create derivative works from any part of our website without our express written consent.
                        </p>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">4.2 Your Rights</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          You retain ownership of the original images you upload to our service. However, by uploading content to Text2Image, you grant us a non-exclusive, worldwide, royalty-free license to use, store, and process that content for the purpose of providing and improving our service.
                        </p>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">4.3 AI-Generated Content</h3>
                        <p className="text-muted-foreground leading-relaxed mb-4">
                          For images generated or transformed by our service using Gemini 2:
                        </p>
                        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                          <li>You receive a license to use, reproduce, modify, and share the AI-generated content for personal or commercial purposes</li>
                          <li>You acknowledge that the AI-generated content may resemble existing content created by others</li>
                          <li>You agree not to claim copyright or exclusive rights to substantially similar content created by others independently</li>
                        </ul>
                      </div>
                    </div>
                  </section>

                  <section id="terms-5" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">5. Third-Party Services</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      Our service integrates Google's Gemini 2 AI technology for image transformation. Use of this technology is subject to Google's terms of service and privacy policy. We do not control and are not responsible for the practices of Google or any other third-party services.
                    </p>
                  </section>

                  <section id="terms-6" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">6. Limitation of Liability</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      To the maximum extent permitted by law, Text2Image shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of or inability to use the service.
                    </p>
                  </section>

                  <section id="terms-7" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">7. Disclaimer of Warranties</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      The service is provided "as is" and "as available" without any warranties of any kind, either express or implied, including but not limited to warranties of merchantability, fitness for a particular purpose, or non-infringement.
                    </p>
                  </section>

                  <section id="terms-8" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">8. Changes to Terms</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      We reserve the right to modify these Terms of Use at any time. We will provide notice of significant changes by posting the updated terms on our website. Your continued use of the service after such modifications constitutes your acceptance of the updated terms.
                    </p>
                  </section>

                  <section id="terms-9" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">9. Termination</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      We reserve the right to terminate or suspend your access to the service at any time, for any reason, without notice.
                    </p>
                  </section>

                  <section id="terms-10" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">10. Governing Law</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      These Terms of Use shall be governed by and construed in accordance with the laws of India, without regard to its conflict of law provisions.
                    </p>
                  </section>
                </div>
              </TabsContent>

              <TabsContent value="privacy" className="space-y-8">
                <div className="text-sm text-muted-foreground text-center">
                  Last Updated: March 2025
                </div>
                <TableOfContents sections={privacySection} prefix="privacy" />
                
                <div className="space-y-12">
                  <section id="privacy-1" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">1. Introduction</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      This Privacy Policy explains how Text2Image ("we," "our," or "us") collects, uses, and shares information about you when you use our website and services. We are committed to protecting your privacy and handling your data transparently.
                    </p>
                  </section>

                  <section id="privacy-2" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">2. Information We Collect</h2>
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-xl font-semibold mb-2">2.1 Information You Provide</h3>
                        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                          <li>Images you upload to our service</li>
                          <li>Text prompts you provide for image transformation</li>
                          <li>Contact information if you choose to provide it (e.g., email address for newsletter signup)</li>
                          <li>Feedback or other communications you send to us</li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">2.2 Information Automatically Collected</h3>
                        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                          <li>Log data (IP address, browser type, pages visited, time spent)</li>
                          <li>Device information (device type, operating system)</li>
                          <li>Cookies and similar technologies</li>
                        </ul>
                      </div>
                    </div>
                  </section>

                  <section id="privacy-3" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">3. How We Use Your Information</h2>
                    <p className="text-muted-foreground leading-relaxed mb-4">We use the information we collect to:</p>
                    <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                      <li>Provide and maintain our service</li>
                      <li>Process and complete your image transformation requests</li>
                      <li>Improve and optimize our service</li>
                      <li>Communicate with you about our service</li>
                      <li>Ensure the security and proper functioning of our service</li>
                      <li>Analyze usage patterns and trends</li>
                    </ul>
                  </section>

                  <section id="privacy-4" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">4. Third-Party Services</h2>
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-xl font-semibold mb-2">4.1 Google Gemini 2</h3>
                        <p className="text-muted-foreground leading-relaxed mb-4">We use Google's Gemini 2 AI technology to process and transform images. When you use our service to transform images:</p>
                        <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                          <li>Your uploaded images and text prompts are sent to Google's Gemini 2 service</li>
                          <li>This data is processed according to Google's privacy policy</li>
                          <li>Google may use this data to improve their AI models</li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">4.2 Analytics and Cookies</h3>
                        <p className="text-muted-foreground leading-relaxed">We use analytics services and cookies to collect information about how users interact with our website. You can control cookie preferences through your browser settings.</p>
                      </div>
                    </div>
                  </section>

                  <section id="privacy-5" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">5. Data Retention</h2>
                    <p className="text-muted-foreground leading-relaxed">We retain your uploaded images and generated content for a limited time necessary to provide our service. We may retain log data and analytics for a longer period for service improvement and security purposes.</p>
                  </section>

                  <section id="privacy-6" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">6. Data Security</h2>
                    <p className="text-muted-foreground leading-relaxed">We implement reasonable security measures to protect your information from unauthorized access, alteration, or destruction. However, no method of transmission over the Internet or electronic storage is 100% secure.</p>
                  </section>

                  <section id="privacy-7" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">7. Your Rights</h2>
                    <p className="text-muted-foreground leading-relaxed mb-4">Depending on your location, you may have certain rights regarding your personal information, including:</p>
                    <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                      <li>Right to access your personal information</li>
                      <li>Right to correct inaccurate information</li>
                      <li>Right to delete your personal information</li>
                      <li>Right to restrict or object to processing</li>
                      <li>Right to data portability</li>
                    </ul>
                    <p className="text-muted-foreground leading-relaxed mt-4">To exercise these rights, please contact us using the information provided in the "Contact Us" section.</p>
                  </section>

                  <section id="privacy-8" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">8. Children's Privacy</h2>
                    <p className="text-muted-foreground leading-relaxed">Our service is not intended for children under the age of 13, and we do not knowingly collect personal information from children under 13. If we become aware that we have collected personal information from a child under 13, we will take steps to delete such information.</p>
                  </section>

                  <section id="privacy-9" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">9. Changes to This Privacy Policy</h2>
                    <p className="text-muted-foreground leading-relaxed">We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.</p>
                  </section>

                  <section id="privacy-10" className="scroll-mt-16">
                    <h2 className="text-2xl font-bold mb-4">10. Contact Us</h2>
                    <p className="text-muted-foreground leading-relaxed">If you have any questions about this Privacy Policy, please contact us using the "Contact Us" section.</p>
                  </section>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </main>
      <Footer />
      
      {showBackToTop && (
        <Button
          className="fixed bottom-8 right-8 rounded-full p-4 shadow-lg"
          onClick={scrollToTop}
          variant="secondary"
        >
          ↑ Back to Top
        </Button>
      )}
    </div>
  )
}