"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Dialog, DialogTrigger } from "@/components/ui/dialog"
import { RecaptchaForm } from "@/components/recaptcha-form"

export default function Contact() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <section className="py-8">
          <div className="container max-w-4xl">
            <div className="text-center space-y-8 md:space-y-10">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-6xl font-bold tracking-tighter">
                  Contact Us
                </h1>
                <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                  Have questions or feedback? Fill out our contact form and we'll get back to you.
                </p>
                <div className="bg-muted/30 rounded-lg p-6 max-w-2xl mx-auto border border-border/50 backdrop-blur-sm">
                  <p className="text-base text-muted-foreground leading-relaxed">
                    We're currently in beta phase and actively working to improve our AI image generation service. Your feedback is invaluable in helping us enhance the tool and create a better experience for everyone. Thank you for your support.
                  </p>
                </div>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="text-lg relative overflow-hidden group transition-all duration-300 ease-out hover:scale-105 hover:shadow-xl">
                    <span className="relative z-10">Get in Touch</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/10 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
                  </Button>
                </DialogTrigger>
                <RecaptchaForm
                  formUrl="https://forms.gle/LviKS9CoeZWUHrdQ9"
                  title="Contact Form"
                />
              </Dialog>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}