"use client"

import { ImageGenerator } from "@/components/image-generator"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Sparkles, Upload, PenLine, Download, ArrowRight, Wand2, Palette } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useState, useEffect } from "react"

export default function Home() {
  const [currentWord, setCurrentWord] = useState(0)
  const words = ["Create", "Edit", "Transform"]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentWord((prev) => (prev + 1) % words.length)
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-12 md:py-20 overflow-hidden bg-slate-100 dark:bg-slate-900 before:absolute before:inset-0 before:bg-[radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.4)_0%,rgba(255,255,255,0)_60%)] before:opacity-90 before:bg-[size:32px_32px] before:bg-[linear-gradient(to_right,rgba(255,255,255,0.3)_3px,transparent_3px),linear-gradient(to_bottom,rgba(255,255,255,0.3)_3px,transparent_3px)] dark:before:bg-[radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.2)_0%,rgba(255,255,255,0)_60%)] after:absolute after:inset-0 after:bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.4)_0%,rgba(255,255,255,0)_60%)] after:opacity-90 after:bg-[size:32px_32px] after:bg-[linear-gradient(to_right,rgba(255,255,255,0.3)_3px,transparent_3px),linear-gradient(to_bottom,rgba(255,255,255,0.3)_3px,transparent_3px)] dark:after:bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.2)_0%,rgba(255,255,255,0)_60%)]">

          <div className="container relative z-10">
            <div className="text-center space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold tracking-tighter flex flex-col items-center">
                <div className="flex items-center space-x-2">
                  <AnimatePresence mode="wait">
                    <motion.span
                      key={words[currentWord]}
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      exit={{ y: -20, opacity: 0 }}
                      transition={{ duration: 0.5 }}
                      className="inline-block"
                    >
                      {words[currentWord]}
                    </motion.span>
                  </AnimatePresence>
                </div>
                <div className="mt-2">
                  Images with Just Words
                </div>
              </h1>
              <p className="text-xl text-muted-foreground max-w-[600px] mx-auto">
                Harness the power of AI to edit and transform your images using simple text descriptions. No complex tools needed.
              </p>
              <div className="pt-4">
                <Link href="/tool">
                  <Button size="lg" className="font-medium">
                    Try Text2Image Now - 100% Free
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Sample Transformation Section */}
        <section className="py-20 bg-slate-50 dark:bg-slate-800/50">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">See the Magic in Action</h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto items-center">
              <div className="space-y-4 text-center flex flex-col h-full">
                <Dialog>
                  <DialogTrigger asChild>
                    <div className="flex-1 flex items-center justify-center h-[400px] cursor-pointer">
                      <img src="/sample-1-before.jpg" alt="Original sunset image" className="w-full h-full object-contain rounded-lg shadow-lg hover:opacity-90 transition-opacity" />
                    </div>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl p-0 overflow-hidden bg-transparent border-0">
                    <DialogTitle className="sr-only">Image Preview</DialogTitle>
                    <img src="/sample-1-before.jpg" alt="Original sunset image" className="w-full h-full object-contain" />
                  </DialogContent>
                </Dialog>
                <div className="h-[60px] flex flex-col items-center gap-1">
                  <p className="text-lg font-medium">Original Sunset Scene</p>
                  <p className="text-sm text-muted-foreground">A beautiful sunset with birds flying and family enjoying the beach</p>
                </div>
              </div>
              <div className="space-y-4 text-center flex flex-col h-full">
                <Dialog>
                  <DialogTrigger asChild>
                    <div className="flex-1 flex items-center justify-center h-[400px] cursor-pointer">
                      <img src="/sample-1-after.jpg" alt="Moonrise transformation" className="w-full h-full object-contain rounded-lg shadow-lg hover:opacity-90 transition-opacity" />
                    </div>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl p-0 overflow-hidden bg-transparent border-0">
                    <DialogTitle className="sr-only">Image Preview</DialogTitle>
                    <img src="/sample-1-after.jpg" alt="Moonrise transformation" className="w-full h-full object-contain" />
                  </DialogContent>
                </Dialog>
                <div className="h-[60px] flex flex-col items-center gap-1">
                  <p className="text-lg font-medium">Moonrise Transformation</p>
                  <p className="text-sm text-muted-foreground">"Update this photo to be of moonrise now"</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">Powerful AI Features</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="p-6 space-y-4">
                <div className="flex justify-center">
                  <Sparkles className="h-16 w-16 text-primary" />
                </div>
                <h3 className="font-semibold text-center">Text to Image</h3>
                <p className="text-sm text-muted-foreground text-center">Create stunning images from your text descriptions</p>
              </Card>
              <Card className="p-6 space-y-4">
                <div className="flex justify-center">
                  <PenLine className="h-16 w-16 text-primary" />
                </div>
                <h3 className="font-semibold text-center">Natural Language Editing</h3>
                <p className="text-sm text-muted-foreground text-center">Transform images using simple text commands</p>
              </Card>
              <Card className="p-6 space-y-4">
                <div className="flex justify-center">
                  <Wand2 className="h-16 w-16 text-primary" />
                </div>
                <h3 className="font-semibold text-center">Style Customization</h3>
                <p className="text-sm text-muted-foreground text-center">Apply creative styles and artistic effects</p>
              </Card>
              <Card className="p-6 space-y-4">
                <div className="flex justify-center">
                  <Palette className="h-16 w-16 text-primary" />
                </div>
                <h3 className="font-semibold text-center">Creative Transformation</h3>
                <p className="text-sm text-muted-foreground text-center">Reimagine your images in unique ways</p>
              </Card>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-20 bg-slate-100 dark:bg-slate-900">
          <div className="container">
            <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
              <div className="space-y-2">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4">
                  <span className="font-bold">1</span>
                </div>
                <h3 className="font-semibold">Describe</h3>
                <p className="text-sm text-muted-foreground">Describe the image you want to create</p>
              </div>
              <div className="space-y-2">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4">
                  <span className="font-bold">2</span>
                </div>
                <h3 className="font-semibold">Generate</h3>
                <p className="text-sm text-muted-foreground">AI creates your imagined image</p>
              </div>
              <div className="space-y-2">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4">
                  <span className="font-bold">3</span>
                </div>
                <h3 className="font-semibold">Transform</h3>
                <p className="text-sm text-muted-foreground">Modify images using natural language</p>
              </div>
              <div className="space-y-2">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4">
                  <span className="font-bold">4</span>
                </div>
                <h3 className="font-semibold">Download</h3>
                <p className="text-sm text-muted-foreground">Save your created or transformed image</p>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-slate-50 dark:bg-slate-800/50">
          <div className="container max-w-4xl">
            <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
            <Accordion type="single" collapsible className="space-y-4">
              <AccordionItem value="free" className="border-none">
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <AccordionTrigger className="px-6 py-4">
                    <div className="flex items-center justify-between w-full">
                      <span className="font-semibold text-lg">Is it really free?</span>
                      <span className="text-primary mr-2">💎</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6">
                    <p className="text-muted-foreground">Yes! Text2Image is completely free to use during our beta period.</p>
                  </AccordionContent>
                </div>
              </AccordionItem>

              <AccordionItem value="image-types" className="border-none">
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <AccordionTrigger className="px-6 py-4">
                    <div className="flex items-center justify-between w-full">
                      <span className="font-semibold text-lg">What types of images can I edit?</span>
                      <span className="text-primary mr-2">🖼️</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6">
                    <p className="text-muted-foreground">You can upload most common image formats (JPG, PNG, etc). For best results, use clear, high-quality images.</p>
                  </AccordionContent>
                </div>
              </AccordionItem>

              <AccordionItem value="processing-time" className="border-none">
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <AccordionTrigger className="px-6 py-4">
                    <div className="flex items-center justify-between w-full">
                      <span className="font-semibold text-lg">How long does it take to process an image?</span>
                      <span className="text-primary mr-2">⚡</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6">
                    <p className="text-muted-foreground">Most transformations take just a few seconds, depending on the complexity of your request.</p>
                  </AccordionContent>
                </div>
              </AccordionItem>

              <AccordionItem value="beta-period" className="border-none">
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <AccordionTrigger className="px-6 py-4">
                    <div className="flex items-center justify-between w-full">
                      <span className="font-semibold text-lg">How long will the beta period last?</span>
                      <span className="text-primary mr-2">🚀</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6">
                    <p className="text-muted-foreground">We haven't set a specific end date for our beta period yet. We're focused on gathering user feedback and improving the service before making any decisions about timing.</p>
                  </AccordionContent>
                </div>
              </AccordionItem>

              <AccordionItem value="prompt-tips" className="border-none">
                <div className="bg-white dark:bg-slate-900 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <AccordionTrigger className="px-6 py-4">
                    <div className="flex items-center justify-between w-full">
                      <span className="font-semibold text-lg">What kind of prompts work best?</span>
                      <span className="text-primary mr-2">✨</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-6">
                    <p className="text-muted-foreground">Clear, descriptive prompts work best. Try to include details about style, mood, and specific elements you want in the image. For example: "A peaceful mountain lake at sunset with warm orange colors."</p>
                  </AccordionContent>
                </div>
              </AccordionItem>
            </Accordion>
          </div>
        </section>

        {/* Final CTA Section */}
        <section className="py-20 bg-primary text-primary-foreground">
          <div className="container text-center space-y-6">
            <h2 className="text-3xl font-bold">Ready to Transform Your Images?</h2>
            <p className="text-xl opacity-90 max-w-[600px] mx-auto">
              Join thousands of users who are already creating amazing transformations with Text2Image.
            </p>
            <div className="pt-4">
              <Link href="/tool">
                <Button size="lg" className="font-medium bg-white text-primary hover:bg-white/90 hover:scale-105 transition-transform shadow-lg">
                  Try Text2Image Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

